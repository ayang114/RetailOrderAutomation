from flask import Flask, request, send_file
import pandas as pd
import os

app = Flask(__name__)

@app.route('/')
def upload_form():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Upload CSV File</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 20px;
            }
            h1 {
                color: #333;
            }
            form {
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            input[type="file"] {
                margin-bottom: 10px;
            }
            input[type="submit"] {
                background: #28a745;
                color: #fff;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            input[type="submit"]:hover {
                background: #218838;
            }
        </style>
    </head>
    <body>

    <h1>Upload a CSV File</h1>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="file" accept=".csv" required>
        <br>
        <input type="submit" value="Upload">
    </form>

    </body>
    </html>
    '''

@app.route('/', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded!', 400

    file = request.files['file']

    # Check the uploaded file's name and content type
    print(f"Uploaded file name: {file.filename}")
    print(f"Uploaded file content type: {file.content_type}")

    # Check if the file has a valid CSV extension and content type
    if (file.filename.endswith('.csv') or 
        file.content_type in ['text/csv', 'application/csv', 'text/plain']):
        
        input_file = 'input.csv'
        file.save(input_file)

        output_file = 'output.csv'
        process_csv(input_file, output_file)

        return send_file(output_file, as_attachment=True)
    
    return 'Invalid file type! Please upload a CSV file.', 400


def process_csv(input_file, output_file):
    try:
        df = pd.read_csv(input_file, encoding='ISO-8859-1')  # Use ISO-8859-1 encoding
    except UnicodeDecodeError as e:
        return f"Error reading the CSV file: {e}"

    # Check if required columns exist
    required_columns = ['Item', 'Quantity On Hand']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    # Retain only the "Item" and "Quantity On Hand" columns
    df_filtered = df[required_columns]

    # Add new columns with default values (e.g., 0 or empty)
    additional_columns = ['S', 'M', 'L', 'XL', '1X', '2X', '3X', '4X', 'GrandTotal']
    for col in additional_columns:
        df_filtered[col] = 0  # You can change this to '' if you prefer empty strings

    # Save the modified DataFrame to a new CSV file
    df_filtered.to_csv(output_file, index=False)




if __name__ == '__main__':
    app.run(debug=True)
