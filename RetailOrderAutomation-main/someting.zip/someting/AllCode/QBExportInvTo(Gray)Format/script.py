from flask import Flask, request, send_file
import pandas as pd
import os
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def upload_form():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Upload CSV File</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 20px;
            }
            h1 {
                color: #333;
            }
            form {
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            input[type="file"] {
                margin-bottom: 10px;
            }
            input[type="submit"] {
                background: #28a745;
                color: #fff;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            input[type="submit"]:hover {
                background: #218838;
            }
        </style>
    </head>
    <body>

    <h1>Upload a CSV File</h1>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="file" accept=".csv" required>
        <br>
        <input type="submit" value="Upload">
    </form>

    </body>
    </html>
    '''

@app.route('/', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded!', 400

    file = request.files['file']

    if (file.filename.endswith('.csv') or 
        file.content_type in ['text/csv', 'application/csv', 'text/plain']):
        
        input_file = 'input.csv'
        file.save(input_file)

        output_file = 'output.csv'

        # Delete output file if it already exists
        if os.path.exists(output_file):
            os.remove(output_file)

        process_csv(input_file, output_file)

        return send_file(output_file, as_attachment=True)
    
    return 'Invalid file type! Please upload a CSV file.', 400

def process_csv(input_file, output_file):
    try:
        df = pd.read_csv(input_file, encoding='ISO-8859-1')
    except UnicodeDecodeError as e:
        return f"Error reading the CSV file: {e}"

    required_columns = ['Item', 'Quantity On Hand']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    processed_data = []

    for _, row in df.iterrows():
        sku_parts = row['Item'].split('-')
        if len(sku_parts) != 3:
            continue  # Skip rows that don't have the expected SKU format
        
        style = sku_parts[0]
        color = sku_parts[1]
        size = sku_parts[2]
        quantity = row['Quantity On Hand']

        processed_row = {
            'Item': style,
            'Color': color,
            'S': 0,
            'M': 0,
            'L': 0,
            'XL': 0,
            '1X': 0,
            '2X': 0,
            '3X': 0,
            '4X': 0,
            'GrandTotal': 0
        }

        if size in processed_row:
            processed_row[size] = quantity
            processed_row['GrandTotal'] += quantity

        processed_data.append(processed_row)

    df_processed = pd.DataFrame(processed_data)
    df_final = df_processed.groupby(['Item', 'Color'], as_index=False).sum()

    df_final.to_csv(output_file, index=False)

if __name__ == '__main__':
    app.run(debug=True)
