from flask import Flask, request, render_template_string
import pandas as pd

app = Flask(__name__)

@app.route('/')
def upload_form():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Upload Excel File</title>
    </head>
    <body>
        <h1>Upload an Excel File</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="file" accept=".xlsx, .xls" required>
            <br>
            <input type="submit" value="Upload">
        </form>
    </body>
    </html>
    '''

@app.route('/', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded!', 400

    file = request.files['file']
    
    if file.filename.endswith(('.xlsx', '.xls')):
        df = pd.read_excel(file)

        # Filter out rows where the first column is 'CO129PL'
        filtered_df = df[df[df.columns[0]] != 'CO129PL']

        # Check for duplicates based on the first two columns in the filtered DataFrame
        duplicates = filtered_df[filtered_df.duplicated(subset=[filtered_df.columns[0], filtered_df.columns[1]], keep=False)]

        if not duplicates.empty:
            return render_template_string('''
                <h2>Duplicate Rows Found:</h2>
                <pre>{{ duplicates.to_html()|safe }}</pre>
                <a href="/">Upload another file</a>
            ''', duplicates=duplicates)
        else:
            return 'No duplicates found in the first two columns!'
    
    return 'Invalid file type! Please upload an Excel file.', 400

if __name__ == '__main__':
    app.run(debug=True)
