sku			quantity-purchased
MK5178-BABYYELLOW-L	1

->

Style	Color	Size	Quantity
MK5178	BABY YELLOW	L	1
