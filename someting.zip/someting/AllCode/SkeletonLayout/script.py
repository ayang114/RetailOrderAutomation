from flask import Flask, request, send_file
import pandas as pd
import os

app = Flask(__name__)

@app.route('/')
def upload_form():
    return '''
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="file" accept=".xlsx">
        <input type="submit">
    </form>
    '''

@app.route('/', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded!', 400

    file = request.files['file']
    if file.filename.endswith('.xlsx'):
        input_file = 'input.xlsx'
        file.save(input_file)

        output_file = 'output.xlsx'
        process_excel(input_file, output_file)

        return send_file(output_file, as_attachment=True)
    return 'Invalid file type!', 400

def process_excel(input_file, output_file):
    df = pd.read_excel(input_file)

    if df.shape[1] < 3:
        raise ValueError("Input file must have at least three columns.")

    df['Formatted'] = '1-' + df.iloc[:, 0].astype(str) + ' style-' + df.iloc[:, 1].astype(str) + ' color-' + df.iloc[:, 2].astype(str) + ' size'
    df.to_excel(output_file, index=False)


if __name__ == '__main__':
    app.run(debug=True)
